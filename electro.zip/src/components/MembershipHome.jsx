import React from 'react';
import { Link } from 'react-router-dom';

const MembershipHome = () => {
  return (
    <section className="membership text-center">
      <div className="container">
        <h2 className="category-title">Explore our Membership</h2>
        <p className="description">
          Get that new clothes feeling every month with a monthly membership. 
          We have a plan that's right for you and your budget.
        </p>
        <Link to="/membership" className="btn1 mw300">LEARN MORE</Link>
      </div>
    </section>
  );
};

export default MembershipHome;
