import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import productBanner from "../assets/images/product.jpg";

const ProductsContent = () => {
  const location = useLocation();
  const [allProducts, setAllProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [maxPrice, setMaxPrice] = useState(500);

  // Parse category from URL on first load
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const categoryParam = searchParams.get("category");
    if (categoryParam) {
      setSelectedCategories([categoryParam.toLowerCase()]);
    }
  }, [location.search]);

  // Load product data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch("/data/product.json");
        const data = await res.json();
        setAllProducts(data);
        setFilteredProducts(data);
      } catch (error) {
        console.error("Error loading product data:", error);
      }
    };
    fetchData();
  }, []);

  // Filter logic
  useEffect(() => {
    const filtered = allProducts.filter((product) => {
      const matchCategory =
        selectedCategories.length === 0 ||
        selectedCategories.includes(product.subcategory.toLowerCase());
      const matchPrice = product.offer_price <= maxPrice;
      return matchCategory && matchPrice;
    });
    setFilteredProducts(filtered);
  }, [selectedCategories, maxPrice, allProducts]);

  // Handle category checkbox
  const handleCategoryChange = (e) => {
    const value = e.target.value;
    setSelectedCategories((prev) =>
      e.target.checked ? [...prev, value] : prev.filter((cat) => cat !== value)
    );
  };

  // Handle price range
  const handlePriceChange = (e) => {
    setMaxPrice(Number(e.target.value));
  };

  return (
    <>
      {/* Hero Banner */}
      <section
        className="inner-hero-banner"
        style={{
          background: `url(${productBanner}) 50% 0 no-repeat`,
        }}
      >
        <div className="overlay">
          <div className="container">
            <h1>Our Products</h1>
          </div>
        </div>
      </section>

      {/* Product List */}
      <section className="product-list text-center py-5">
        <div className="container">
          <h2 className="h2">All Products</h2>
          <p className="subtitle mb-50">----------</p>

          <div className="row g-4">
            {/* Filter Sidebar */}
            <div className="col-md-2 text-start">
              <aside className="filter-section">
                {/* Category Filter */}
                <div className="mb-4">
                  <h6 className="fw-bold">Category</h6>
                  {["shirt", "pant", "coat", "shoe", "bag", "accessory"].map(
                    (cat) => (
                      <div key={cat}>
                        <input
                          type="checkbox"
                          value={cat}
                          checked={selectedCategories.includes(cat)}
                          onChange={handleCategoryChange}
                        />{" "}
                        {cat.charAt(0).toUpperCase() + cat.slice(1)}
                      </div>
                    )
                  )}
                </div>

                {/* Price Filter */}
                <div className="mb-4">
                  <h6 className="fw-bold">Filter by price</h6>
                  <div className="p-3">
                    <input
                      type="range"
                      className="form-range"
                      min="0"
                      max="500"
                      step="10"
                      value={maxPrice}
                      onChange={handlePriceChange}
                    />
                  </div>
                  <div className="p-3 text-muted small">
                    Max Price: ${maxPrice}
                  </div>
                </div>
              </aside>
            </div>

            {/* Product Grid */}
            <div className="col-md-10">
              <div className="row" id="product-list">
                {filteredProducts.length > 0 ? (
                  filteredProducts.map((product) => (
                    <div className="col-12 col-sm-6 col-lg-3" key={product.id}>
                      <div className="product-card text-start">
                        <img
                          src={product.image}
                          alt={product.product_name}
                          className="img-fluid w-100"
                        />
                        <h6 className="mt-2">{product.product_name}</h6>
                        <p className="text-muted small mb-1">
                          Category: {product.category}
                        </p>
                        <p className="fw-bold text-dark">
                          ${product.offer_price.toFixed(2)}
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-muted">No products found.</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ProductsContent;
