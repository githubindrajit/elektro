import React from 'react';
import banner1 from '../assets/images/banner1.jpg';
import banner2 from '../assets/images/banner2.jpg';
import banner3 from '../assets/images/banner3.jpg';

import { Link } from 'react-router-dom';

const HeroCarousel = () => {
  return (
    <section id="heroCarousel" className="carousel slide p-0" data-bs-ride="carousel">
      <div className="carousel-inner">
        {/* Slide 1 */}
        <div className="carousel-item active" style={{ backgroundImage: `url(${banner1})` }}>
          <div className="carousel-caption d-flex justify-content-center justify-content-md-start align-items-end flex-column">

            <div className="promo-card">
              <div className="brd">
                <div className="subtitle">SALE UP TO 30% OFF</div>
                <div className="title">iGadgets Collection</div>
                <div className="description">Only in this week. Don’t miss!</div>
                <Link to="/products" className="btn1 mx-auto">Shop Now</Link>
              </div>
            </div>

          </div>
        </div>

        {/* Slide 2 */}
        <div className="carousel-item" style={{ backgroundImage: `url(${banner2})` }}>
          <div className="carousel-caption d-flex justify-content-center align-items-end flex-column">
            <div className="promo-card">
              <div className="brd">
                <div className="subtitle">New Collection</div>
                <div className="title">New Best Deals Apple Watch</div>
                <div className="description">- Ever Powerful sensors to monitor your fitness</div>
                <Link to="/products" className="btn1 mx-auto">Shop Now</Link>
              </div>
            </div>
          </div>
        </div>

        {/* Slide 3 */}
        <div className="carousel-item" style={{ backgroundImage: `url(${banner3})` }}>
          <div className="carousel-caption d-flex justify-content-center align-items-end flex-column">
            <div className="promo-card">
              <div className="brd">
                <div className="subtitle">SALE UP TO 30% OFF</div>
                <div className="title">Accessories Phone Series</div>
                <div className="description">- Ever Powerful sensors to monitor your fitness</div>
                <Link to="/products" className="btn1 mx-auto">Shop Now</Link>
              </div>
            </div>
          </div>
        </div>

        
      </div>

      {/* Carousel Controls */}
      <button className="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
        <span className="carousel-control-prev-icon"></span>
      </button>
      <button className="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
        <span className="carousel-control-next-icon"></span>
      </button>
    </section>
  );
};

export default HeroCarousel;
