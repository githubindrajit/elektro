import React from "react";

// import ab-pic from '../assets/images/about.jpg';
import abpic1 from '../assets/images/ab1.jpg';
import abpic2 from '../assets/images/ab2.jpg';
import abpic3 from '../assets/images/ab3.jpg';


import aboutImage from "../assets/images/about.jpg";




const AboutContent = () => {
  return (
    <>
      {/* Hero Banner */}
      <section
        className="inner-hero-banner"
        style={{
        background: `url(${aboutImage}) 50% 0 no-repeat`,
        }}
      >
        <div className="overlay">
          <div className="container">
            <h1>About Us</h1>
          </div>
        </div>
      </section>

      {/* Intro Section */}
      <section className="text-center">
        <div className="container">
          <h2 className="h2">We are Eva</h2>
          <p className="subtitle">----------</p>
          <p style={{ maxWidth: "800px", margin: "0 auto" }}>
            EVA Fashion brings you the best in style for both women and men —
            from casual denim to chic seasonal trends. <br />
            We believe in effortless fashion that speaks confidence, comfort,
            and bold personality. Explore our collections and make your fashion
            statement today.
          </p>
        </div>
      </section>

      {/* Our Mission */}
      <section className="about-section">
        <div className="container">
          <div className="ab-pic">
            <img src={abpic1} alt="Eva Fashion Store" />
          </div>
          <div className="ab-content">
            <h2 className="h2">Our Mission</h2>
            <p>
              EVA Fashion brings you the best in style for both women and men –
              from casual denim to chic seasonal trends. We believe in
              effortless fashion that speaks confidence, comfort, and bold
              personality. Explore our collections and make your fashion
              statement today.
            </p>
            <a href="#" className="btn-explore">
              Explore
            </a>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="about-section evn">
        <div className="container flex-md-row-reverse">
          <div className="ab-pic">
            <img src={abpic2} alt="Eva Fashion Store" />
          </div>
          <div className="ab-content">
            <h2>Our Story</h2>
            <p>
              EVA Fashion brings you the best in style for both women and men –
              from casual denim to chic seasonal trends. We believe in
              effortless fashion that speaks confidence, comfort, and bold
              personality. Explore our collections and make your fashion
              statement today.
            </p>
            <a href="#" className="btn-explore">
              Explore
            </a>
          </div>
        </div>
      </section>

      {/* Our Approach */}
      <section className="about-section mb-60">
        <div className="container">
          <div className="ab-pic">
            <img src={abpic3} alt="Eva Fashion Store" />
          </div>
          <div className="ab-content">
            <h2>Our Approach</h2>
            <p>
              EVA Fashion brings you the best in style for both women and men –
              from casual denim to chic seasonal trends. We believe in
              effortless fashion that speaks confidence, comfort, and bold
              personality. Explore our collections and make your fashion
              statement today.
            </p>
            <a href="#" className="btn-explore">
              Explore
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutContent;
