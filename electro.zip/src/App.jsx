import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

import Home from './pages/Home';
import Products from './pages/Products';
import About from './pages/About';
import Cart from './pages/Cart';
import Contact from './pages/Contact';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Wishlist from './pages/Wishlist';
import Checkout from './pages/Checkout';
import ProductDetail from './pages/ProductDetail';
import Thank from './pages/Thank';

import { CartWishlistProvider } from './context/CartWishlistContext'; // ✅ Import context

const App = () => {
  return (
    <CartWishlistProvider> {/* ✅ Wrap app with context */}
      <BrowserRouter>
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/products" element={<Products />} />
            <Route path="/about" element={<About />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/wishlist" element={<Wishlist />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/product-details" element={<ProductDetail />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/thank" element={<Thank />} />
          </Routes>
        </main>
        <Footer />
      </BrowserRouter>
    </CartWishlistProvider>
  );
};

export default App;
