import React, { createContext, useState, useContext } from 'react';
import { ToastContainer, toast } from 'react-toastify';

export const CartWishlistContext = createContext();

export const CartWishlistProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);
  const [wishlistItems, setWishlistItems] = useState([]);

  // Add to cart, avoid duplicates and increase quantity if exists
  const addToCart = (product) => {
    setCartItems((prev) => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.id === product.id ? { ...item, quantity: (item.quantity || 1) + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    toast.success("Product added to Cart");
  };

  // Add to wishlist, avoid duplicates
  const addToWishlist = (product) => {
    setWishlistItems((prev) => {
      if (prev.find(item => item.id === product.id)) {
      
        return prev;
      }
      return [...prev, product];
    });

          toast.success("Product added to Wishlist");

  };

  const removeFromCart = (id) => {
    setCartItems((prev) => prev.filter(item => item.id !== id));
    toast.info("Product removed from Cart");
  };

  // ✅ Remove from wishlist function
  const removeFromWishlist = (id) => {
    setWishlistItems((prev) => prev.filter(item => item.id !== id));
    toast.info("Product removed from Wishlist");
  };

  return (
    <CartWishlistContext.Provider
      value={{
        cartItems,
        wishlistItems,
        addToCart,
        addToWishlist,
        removeFromCart,
        removeFromWishlist, // expose removeFromWishlist
      }}
    >
      {children}
      {/* <ToastContainer position="top-right" autoClose={2000} /> */}
    </CartWishlistContext.Provider>
  );
};

export const useCartWishlist = () => useContext(CartWishlistContext);
