import React from 'react'
import ProductDetailContent from '../components/ProductDetailCOntent'

const ProductDetail = () => {
  return (
    <div>
        
        <ProductDetailContent />


    </div>
  )
}

export default ProductDetail