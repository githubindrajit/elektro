import React from 'react'
import AboutContent from '../components/AboutContent'

const About = () => {
  return (
    <div>

<AboutContent />

    </div>
  )
}

export default About