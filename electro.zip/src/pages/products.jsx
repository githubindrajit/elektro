import React from 'react'
import ProductsContent from '../components/ProductsContent'


const products = () => {
  return (
    <div>
      
    <ProductsContent />

    </div>
  )
}

export default products