import React from 'react';
import HeroCarousel from '../components/HeroCarousel';
import CategoryHome from '../components/CategoryHome';
import BestSellingHome from '../components/BestSellingHome';
import MembershipHome from '../components/MembershipHome';
import FeaturedHome from '../components/FeaturedHome';
import HighFashionHome from '../components/HighFashionHome';
import NewsletterHome from '../components/NewsletterHome';
import EvaIntroHome from '../components/EvaIntroHome';
import InstagramHome from '../components/InstagramHome';
import InfoHome from '../components/InfoHome';
import CollectionHome from '../components/CollectionHome';


const Home = () => {
  return (
    <>

<HeroCarousel />

<CategoryHome />

<BestSellingHome />

<MembershipHome />

<FeaturedHome />

{/* <HighFashionHome />

<InfoHome />

<CollectionHome />

<EvaIntroHome /> */}

<InstagramHome />

<NewsletterHome />








    </>


  );
};

export default Home;
