import React from 'react'
import CartContent from '../components/CartContent'

const Cart = () => {
  return (
    <div>
      <CartContent />

    </div>
  )
}

export default Cart