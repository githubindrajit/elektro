import React from 'react'
import ContactContent from '../components/ContactContent'


const Contact = () => {
  return (
    <div>
      
      <ContactContent />

    </div>
  )
}

export default Contact