import React from 'react'
import CheckoutContent from '../components/CheckoutContent'

const Checkout = () => {
  return (
    <div>
        
        <CheckoutContent />
    </div>
  )
}

export default Checkout