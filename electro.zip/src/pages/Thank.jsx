import React from 'react'
import ThankContent from '../components/ThankContent'

const Thank = () => {
  return (
    <div>
        
<ThankContent />

    </div>
  )
}

export default Thank