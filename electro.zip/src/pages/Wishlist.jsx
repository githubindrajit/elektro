import React from 'react'
import WishlistContent from '../components/WishlistContent'

const Wishlist = () => {
  return (
    <div>
        
<WishlistContent />

    </div>
  )
}

export default Wishlist